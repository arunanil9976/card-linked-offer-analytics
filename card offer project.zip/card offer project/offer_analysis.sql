CREATE DATABASE amex_offer_analysis;
USE amex_offer_analysis;
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    age INT,
    city VARCHAR(50),
    spend_segment VARCHAR(10)
);

CREATE TABLE merchants (
    merchant_id INT PRIMARY KEY,
    merchant_category VARCHAR(50),
    city VARCHAR(50)
);

CREATE TABLE offers (
    offer_id VARCHAR(10) PRIMARY KEY,
    merchant_id INT,
    offer_type VARCHAR(20),
    discount_pct INT,
    start_date DATE,
    end_date DATE
);

CREATE TABLE transactions (
    transaction_id INT PRIMARY KEY,
    customer_id INT,
    merchant_id INT,
    transaction_date DATE,
    transaction_amount DECIMAL(10,2),
    offer_applied CHAR(1)
);

show tables;

select * from customers;
select * from merchants;
select * from offers;
select * from transactions;

SELECT 
    COUNT(*) AS total_transactions,
    SUM(offer_applied = 'Y') AS redeemed_transactions,
    ROUND(100 * SUM(offer_applied = 'Y') / COUNT(*), 2) AS redemption_rate_pct
FROM transactions;

SELECT
    t.merchant_id,
    ROUND(AVG(CASE 
        WHEN t.transaction_date < o.start_date 
        THEN t.transaction_amount END), 2) AS avg_spend_before,

    ROUND(AVG(CASE 
        WHEN t.transaction_date BETWEEN o.start_date AND o.end_date 
        THEN t.transaction_amount END), 2) AS avg_spend_during,

    ROUND(
        AVG(CASE 
            WHEN t.transaction_date BETWEEN o.start_date AND o.end_date 
            THEN t.transaction_amount END)
        -
        AVG(CASE 
            WHEN t.transaction_date < o.start_date 
            THEN t.transaction_amount END),
    2) AS incremental_spend
FROM transactions t
JOIN offers o
    ON t.merchant_id = o.merchant_id
GROUP BY t.merchant_id
HAVING avg_spend_before IS NOT NULL
   AND avg_spend_during IS NOT NULL;


SELECT
    merchant_id,
    COUNT(*) AS total_transactions,
    SUM(offer_applied = 'Y') AS redeemed_txns,
    ROUND(AVG(transaction_amount), 2) AS avg_transaction_value
FROM transactions
GROUP BY merchant_id
ORDER BY redeemed_txns DESC, avg_transaction_value DESC
LIMIT 10;


SELECT
    c.spend_segment,
    COUNT(*) AS total_transactions,
    SUM(t.offer_applied = 'Y') AS redeemed_transactions,
    ROUND(AVG(t.transaction_amount), 2) AS avg_spend
FROM transactions t
JOIN customers c
    ON t.customer_id = c.customer_id
GROUP BY c.spend_segment
ORDER BY redeemed_transactions DESC;


SELECT
    m.merchant_category,
    COUNT(*) AS total_txns,
    SUM(t.offer_applied = 'Y') AS redeemed_txns,
    ROUND(100 * SUM(t.offer_applied = 'Y') / COUNT(*), 2) AS redemption_rate_pct
FROM transactions t
JOIN merchants m
    ON t.merchant_id = m.merchant_id
GROUP BY m.merchant_category
ORDER BY redemption_rate_pct DESC;


SELECT
    m.city,
    COUNT(*) AS total_txns,
    SUM(t.offer_applied = 'Y') AS redeemed_txns,
    ROUND(AVG(t.transaction_amount), 2) AS avg_spend
FROM transactions t
JOIN merchants m
    ON t.merchant_id = m.merchant_id
GROUP BY m.city
ORDER BY redeemed_txns DESC;

SELECT
    customer_id,
    COUNT(*) AS total_txns,
    SUM(offer_applied = 'Y') AS offer_txns
FROM transactions
GROUP BY customer_id
HAVING total_txns > 3
ORDER BY offer_txns DESC
LIMIT 20;


SELECT
    o.offer_type,
    COUNT(*) AS total_txns,
    SUM(t.offer_applied = 'Y') AS redeemed_txns,
    ROUND(AVG(t.transaction_amount), 2) AS avg_spend
FROM transactions t
JOIN offers o
    ON t.merchant_id = o.merchant_id
GROUP BY o.offer_type
ORDER BY redeemed_txns DESC;
